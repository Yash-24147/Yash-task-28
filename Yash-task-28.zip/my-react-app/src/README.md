React Router Navigation App

About

This is a React application that uses React Router DOM to navigate between different pages without reloading the browser.

Technologies Used

React
JavaScript
JSX
CSS
React Router DOM

Features

Created four different pages
Home page for the main landing section
Dashboard page to display dashboard information
Login page for existing users
Register page for new users
Uses BrowserRouter for routing
Uses Routes and Route to manage different pages
Uses Link for navigation without page reload
Separate components for each page
Responsive user interface

How to Run

Create a React project using Vite
Install React Router DOM
Run npm install
Create a pages folder inside src
Create Home.jsx, Dashboard.jsx, Login.jsx and Register.jsx
Add the given code in App.jsx
Add styling in App.css
Open the terminal in the project folder
Run npm run dev
Open the local URL in your browser

Author

Yash
