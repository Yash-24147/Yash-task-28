
import { Link } from "react-router-dom";

function Dashboard() {
  return (
    <div className="page-container">
      <h1>Dashboard</h1>
      <p className="page-description">Welcome to your dashboard!</p>

      <div className="dashboard-cards">
        <div className="dashboard-card">
          <h3>Total Users</h3>
          <h2>1,250</h2>
          <p>Registered users</p>
        </div>

        <div className="dashboard-card">
          <h3>Projects</h3>
          <h2>48</h2>
          <p>Active projects</p>
        </div>

        <div className="dashboard-card">
          <h3>Activities</h3>
          <h2>320</h2>
          <p>Total activities</p>
        </div>
      </div>

      <Link to="/" className="back-btn">Back to Home</Link>
    </div>
  );
}

export default Dashboard;
