
import { Link } from "react-router-dom";

function Login() {
  return (
    <div className="form-page">
      <div className="form-card">
        <h1>Welcome Back!</h1>
        <p>Login to your account</p>

        <form>
          <label>Email Address</label>
          <input type="email" placeholder="Enter your email" required />

          <label>Password</label>
          <input type="password" placeholder="Enter your password" required />

          <button type="submit">Login</button>
        </form>

        <p className="form-footer">
          Don't have an account? <Link to="/signup">Register</Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
