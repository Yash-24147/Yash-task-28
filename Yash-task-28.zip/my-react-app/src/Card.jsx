
function Card({ user }) {
  return (
    <div className="card-border">
      <div className="card">
        <img src={user.image} alt={user.name} />
        <h2>{user.name}</h2>
        <h4>{user.role}</h4>
        <p>{user.description}</p>
        <button>View Profile</button>
      </div>
    </div>
  );
}

export default Card;
